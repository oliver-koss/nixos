#define VERSION_LONG "stable release 1.2.1";
#define VERSION_SHORT "1.2.1"
extern char * mgetty_version;
